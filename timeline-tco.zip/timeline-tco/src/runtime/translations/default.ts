export default {
  _widgetLabel: 'Timeline',
  overallTimeExtent: 'Overall time extent',
  filteringApplied: 'Timeline filtering applied',
  noTlFromHonoredMapWarning: 'Oops! Seems like something went wrong with this map and we cannot get any valid time settings.',
  invalidTimeSpanWarning: 'Please check the widget configurations to make sure the time span is valid.'
}
